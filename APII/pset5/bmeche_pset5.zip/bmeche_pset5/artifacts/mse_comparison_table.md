# MSE Comparison Table (woLAB)

Pipeline blocked at Step 2 because `data/WRDS` is empty in this workspace; real MSE values could not be computed.

| horizon | MSE_Analyst | MSE_RF | MSE_NN | NN_minus_RF | RF_minus_Analyst | NN_minus_Analyst |
| --- | --- | --- | --- | --- | --- | --- |
| q1 | N/A | N/A | N/A | N/A | N/A | N/A |
| q2 | N/A | N/A | N/A | N/A | N/A | N/A |
| q3 | N/A | N/A | N/A | N/A | N/A | N/A |
| y1 | N/A | N/A | N/A | N/A | N/A | N/A |
| y2 | N/A | N/A | N/A | N/A | N/A | N/A |

## NN vs RF Percent Improvement

| horizon | pct_improvement_nn_vs_rf |
| --- | --- |
| q1 | N/A |
| q2 | N/A |
| q3 | N/A |
| y1 | N/A |
| y2 | N/A |
