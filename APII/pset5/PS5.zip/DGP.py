"""
Data Generating Process for Asset Pricing Neural Network Simulations

This module generates synthetic firm-level characteristics and returns data
for testing machine learning models in empirical asset pricing.

Citation: Gu, S., Kelly, B., & Xiu, D. (2020). "Empirical Asset Pricing via Machine Learning."
Review of Financial Studies, 33(5), 2223-2273.

Version: March 10, 2019
@copyright Shihao Gu, Bryan Kelly and Dacheng Xiu
"""

import numpy as np
import pandas as pd
import os


def dgp(datanum=100, hh=[1]):
    """
    Generate simulated asset pricing data with firm characteristics and returns.
    
    This function creates synthetic panel data consisting of:
    - Firm-level characteristics (features) that follow AR(1) processes
    - Factor exposures (betas) based on characteristics
    - Returns from both linear and nonlinear pricing models
    
    Parameters:
    -----------
    datanum : int, default=100
        Number of characteristics to generate (P/2 where P is total features).
        Total features = 2 * datanum (characteristics + their macro interactions)
    
    hh : list of int, default=[1]
        Return horizons to generate (in months).
        hh=[1] generates 1-month returns, hh=[1,3,6] generates 1, 3, and 6-month returns
    
    Data Structure:
    --------------
    - N = 200 firms (cross-sectional dimension)
    - T = 180 months (time-series dimension)
    - Total observations = N × T = 36,000
    
    Generates two models:
    --------------------
    Model 1 (Linear): Returns are linear functions of characteristics
    Model 2 (Nonlinear): Returns include quadratic and interaction terms
    
    Output Files:
    ------------
    Saves to ./Simu/SimuData_{datanum}/ directory:
    - c{M}.csv: Firm characteristics matrix (N*T × 2*datanum)
    - r1_{M}_{h}.csv: Returns from linear model for horizon h
    - r2_{M}_{h}.csv: Returns from nonlinear model for horizon h
    where M = Monte Carlo iteration (1-100)
    """
    
    # Setup output directory structure
    path = './Simu/'
    name = 'SimuData_' + str(datanum)
    
    if not os.path.exists(path):
        os.makedirs(path)
    if not os.path.exists(path + name):
        os.makedirs(path + name)
    
    # Run 100 Monte Carlo simulations
    for M in range(1, 101):
        # Set random seed for reproducibility (unique for each MC iteration)
        np.random.seed(M * 123)
        
        # ==================== Data Dimensions ====================
        n = 200              # Number of firms (cross-section)
        m = datanum // 2     # Number of base characteristics
        T = 180              # Number of time periods (months)
        stdv = 0.05          # Standard deviation of factor shocks
        stde = 0.05          # Standard deviation of idiosyncratic errors
        
        # ==================== Generate Firm Characteristics ====================
        # Each characteristic follows an AR(1) process with persistence ρ ∈ [0.9, 1]
        # This creates realistic persistent but mean-reverting firm attributes
        
        rho = np.random.uniform(0.9, 1, m)  # Persistence parameters for each characteristic
        c = np.zeros((n * T, m))            # Initialize characteristic matrix
        
        for i in range(m):
            # Generate time-series for each firm using AR(1): x_{t+1} = ρ*x_t + ε_t
            x = np.zeros((n, T))
            x[:, 0] = np.random.randn(n)  # Initial values from standard normal
            
            for t in range(T - 1):
                # AR(1) update with variance adjusted to maintain unit unconditional variance
                x[:, t + 1] = rho[i] * x[:, t] + np.random.randn(n) * np.sqrt(1 - rho[i]**2)
            
            # Cross-sectional ranking: Transform to uniform [-1, 1] within each time period
            # This ensures characteristics are comparable across different firms and times
            x1 = x.argsort(0)         # Get sorting indices
            x1 = x1.argsort(0)        # Get ranks (0 to n-1)
            x1 = x1 * 2 / (n + 1) - 1 # Normalize to [-1, 1]
            
            # Reshape from (n × T) to (n*T × 1) and store
            c[:, i] = x1.T.reshape(n * T)
        
        # ==================== Generate Factor Structure ====================
        # Create factor exposures (betas) and factor realizations
        
        per = np.tile(np.arange(n), T)     # Firm identifier: [0,1,...,n-1, 0,1,...,n-1, ...]
        time = np.repeat(np.arange(T), n)  # Time identifier: [0,0,...,0, 1,1,...,1, ...]
        
        # Generate 3 systematic factors with i.i.d. normal shocks
        vt = stdv * np.random.randn(3, T)  # (3 × T) factor realizations
        
        # Factor loadings: First 3 characteristics serve as betas
        beta = c[:, :3]
        betav = np.zeros(n * T)  # Factor contribution to returns
        
        # Compute factor component: Σ β_i * f_t for each observation
        for t in range(T):
            ind = (time == t)
            betav[ind] = beta[ind, :].dot(vt[:, t])
        
        # ==================== Generate Macro Time-Series Variable ====================
        # AR(1) macro variable that will interact with characteristics
        # Models business cycle or aggregate economic conditions
        
        y = np.zeros(T)
        y[0] = np.random.randn(1)
        q = 0.95  # High persistence for macro variable
        
        for t in range(T - 1):
            y[t + 1] = q * y[t] + np.random.randn(1) * np.sqrt(1 - q**2)
        
        # Create characteristic-macro interactions: c_i * y_t
        # This allows characteristic effects to vary with the business cycle
        cy = c.copy()
        for t in range(T):
            ind = (time == t)
            cy[ind, :] = c[ind, :] * y[t]
        
        # Generate idiosyncratic errors from t-distribution (fat tails)
        ep = stde * np.random.standard_t(5, n * T)
        
        # ==================== Save Characteristics ====================
        # Combined feature matrix: [c, c*y] (base characteristics + macro interactions)
        data = np.hstack((c, cy))
        df = pd.DataFrame(data)
        df.to_csv(path + name + '/c%d.csv' % M, index=False)
        
        # ==================== Model 1: Linear Pricing Model ====================
        # Returns: r_t = θ'[c, c*y] + β'f + ε
        # Sparse parameter vector with only a few non-zero coefficients
        
        theta_w = 0.02                    # Scaling factor for coefficients
        theta = np.zeros(2 * m)           # Initialize parameter vector
        theta[0], theta[1], theta[m + 2] = 1, 1, 1  # Only 3 characteristics matter
        theta *= theta_w                  # Scale parameters
        
        # Compute returns: Linear combination + factors + noise
        r1 = np.hstack((c, cy)).dot(theta) + betav + ep
        
        # Generate returns for all requested horizons
        for h in hh:
            if h == 1:
                # 1-month returns: Use as-is
                df = pd.DataFrame(r1)
                df.to_csv(path + name + '/r1_%d_%d.csv' % (M, h), index=False)
            else:
                # Multi-period cumulative returns
                r = np.zeros(len(r1)) / 0.0  # Initialize with NaN
                u = np.unique(per)
                
                for i in range(len(u)):
                    ind = (per == u[i])
                    ret = r1[ind].copy()
                    ret_cumulative = np.zeros(len(ret)) / 0.0  # NaN initialization
                    N = len(ret)
                    
                    # Compute h-period cumulative returns
                    for j in range(N - h + 1):
                        ret_cumulative[j] = np.sum(ret[j:(j + h)])
                    
                    r[ind] = ret_cumulative
                
                df = pd.DataFrame(r)
                df.to_csv(path + name + '/r1_%d_%d.csv' % (M, h), index=False)
        
        # ==================== Model 2: Nonlinear Pricing Model ====================
        # Returns include quadratic and interaction terms
        # z[0] = 2*c[0]^2 (quadratic)
        # z[1] = 1.5*c[0]*c[1] (interaction)
        # z[m+2] = 0.6*sign(c*y[2]) (threshold effect)
        
        z = np.hstack((c, cy)).copy()
        z[:, 0] = 2 * c[:, 0]**2           # Quadratic term
        z[:, 1] = c[:, 0] * c[:, 1] * 1.5  # Interaction term
        z[:, m + 2] = np.sign(cy[:, 2]) * 0.6  # Threshold/sign effect
        
        # Compute nonlinear returns
        r2 = z.dot(theta) + betav + ep
        
        # Generate returns for all requested horizons
        for h in hh:
            if h == 1:
                df = pd.DataFrame(r2)
                df.to_csv(path + name + '/r2_%d_%d.csv' % (M, h), index=False)
            else:
                # Multi-period cumulative returns
                r = np.zeros(len(r2)) / 0.0
                u = np.unique(per)
                
                for i in range(len(u)):
                    ind = (per == u[i])
                    ret = r2[ind].copy()
                    ret_cumulative = np.zeros(len(ret)) / 0.0
                    N = len(ret)
                    
                    for j in range(N - h + 1):
                        ret_cumulative[j] = np.sum(ret[j:(j + h)])
                    
                    r[ind] = ret_cumulative
                
                df = pd.DataFrame(r)
                df.to_csv(path + name + '/r2_%d_%d.csv' % (M, h), index=False)


if __name__ == "__main__":
    """
    Example usage: Generate data with 100 characteristics for 1-month horizon
    """
    print("Generating simulation data...")
    dgp(datanum=100, hh=[1])
    print("Data generation complete. Files saved to ./Simu/SimuData_100/")
