"""
Simulation Tree Models for Asset Pricing
=========================================
This module implements three tree-based machine learning models:
1. Random Forest (RF)
2. Gradient Boosted Regression Trees (GBRT) with squared error loss
3. GBRT with Huber loss (robust to outliers)

These models are used to predict asset returns based on firm characteristics.
"""

import os
import random

from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
import timeit
from auxiliary_func import *

# Monte Carlo simulation identifier
MC = 1
random.seed(MC * 123)  # Set random seed for reproducibility

# Configuration: Set data size (P=100 means 50 characteristics, P=200 means 100 characteristics)
datanum = '100'

# Directory paths for data storage
path = './Simu/'
dirstock = path + '/SimuData_' + datanum + '/'


def write_dir(hh=[1]):
    """
    Create directory structure for saving results.
    
    Parameters:
    -----------
    hh : list of int
        Horizon parameters (e.g., 1=monthly, 3=quarterly, 6=semi-annual, 12=annual)
    
    Creates:
    --------
    - Main output directory for each horizon
    - Subdirectory 'B' for coefficient matrices
    - Subdirectory 'VIP' for variable importance measures
    """
    for h in hh:
        title = path + '/Simu_' + datanum + '/Tree%d' % h
        # Only create directories on first Monte Carlo iteration
        if not os.path.exists(title) and MC == 1:
            os.makedirs(title)
        if not os.path.exists(title + '/B') and MC == 1:
            os.makedirs(title + '/B')
        if not os.path.exists(title + '/VIP') and MC == 1:
            os.makedirs(title + '/VIP')
    return


def Random_forest(nump, ne, xtrain, ytrain, mtrain, xoos, yoos, xtest, ytest):
    '''
    Random Forest Regression Model
    ===============================
    
    Random forests combine predictions from multiple decision trees, where each tree
    is trained on a bootstrap sample of the data and considers only a random subset
    of features at each split. This reduces overfitting and improves generalization.
    
    Parameters:
    -----------
    nump : int
        Number of characteristics in the dataset (determines feature search range)
    ne : int
        Number of trees (estimators) in the forest
    xtrain : ndarray
        Training sample of characteristics (features) [N_train x P]
    ytrain : ndarray
        Training sample of returns (targets) [N_train]
    mtrain : float
        Mean of training returns (used for R² calculation)
    xoos : ndarray
        Out-of-sample characteristics for validation [N_oos x P]
    yoos : ndarray
        Out-of-sample returns for validation [N_oos]
    xtest : ndarray
        Test sample of characteristics (for hyperparameter tuning) [N_test x P]
    ytest : ndarray
        Test sample of returns (for hyperparameter tuning) [N_test]
    
    Returns:
    --------
    r2_oos : float
        Out-of-sample R² (performance metric on validation set)
    r2_is : float
        In-sample R² (performance metric on training set)
    b : ndarray
        Feature importance scores from the best model [P]
    v : ndarray
        Variable importance (VIP) scores [P]
    
    Hyperparameters Tuned:
    ----------------------
    lamv : range
        Number of features considered at each split (max_features)
        - For P=50: try 10, 20, 30, ..., 100
        - For P=100: try 10, 30, 50, ..., 190
    lamc : list
        Maximum depth of each tree (1, 2, 3, 4, 5)
        Deeper trees can capture more complex patterns but risk overfitting
    
    Model Selection Strategy:
    -------------------------
    1. Grid search over all combinations of (max_features, max_depth)
    2. Compute R² on test set for each combination
    3. Select model with highest test R²
    4. Report OOS R² and IS R² for the selected model
    5. Extract feature importances from the selected model
    '''
    
    # Initialize output variables
    r2_oos = 0  # Out-of-sample R²
    r2_is = 0   # In-sample R²
    b = np.zeros(xtrain.shape[1])  # Feature importance scores
    v = np.zeros(xtrain.shape[1])  # VIP scores

    # Define hyperparameter search grid based on dataset size
    if nump == 50:
        lamv = range(10, 110, 10)  # Max features to consider: 10, 20, ..., 100
    if nump == 100:
        lamv = range(10, 200, 20)  # Max features to consider: 10, 30, ..., 190
    
    lamc = [1, 2, 3, 4, 5]  # Tree depth options
    
    # Dictionary to store R² values for different datasets
    # r[0] = test R², r[1] = OOS R², r[2] = in-sample R²
    r = {}
    for i in range(3):
        r[i] = np.zeros((len(lamv), len(lamc)))
    
    # Grid search: try all combinations of max_features and max_depth
    for n1 in range(len(lamv)):
        nf = lamv[n1]  # Current max_features value
        for n2 in range(len(lamc)):
            nn = lamc[n2]  # Current max_depth value
            
            ##############################################################################
            ### TODO: implement the function                                           ###
            ##############################################################################
            # HINTS for students:
            # 1. Create a RandomForestRegressor with current hyperparameters 
            #    (max_depth=nn, n_estimators=ne, max_features=nf)
            # 2. Fit the model on (xtrain, ytrain)
            # 3. Predict on xtest and compute R² = 1 - SSE/SST where:
            #    - SSE = sum((predictions - ytest)²)
            #    - SST = sum((ytest - mtrain)²)
            # 4. Store test R² in r[0][n1, n2]
            # 5. Repeat prediction and R² calculation for xoos → r[1][n1, n2]
            # 6. Repeat prediction and R² calculation for xtrain → r[2][n1, n2]
            ##############################################################################

            

    # Select best hyperparameters based on test R² (fw2 finds indices of maximum value)


    # Retrain model with best hyperparameters


    # Extract feature importances


    # Compute variable importance (VIP) scores


    ##############################################################################
    #                               END OF YOUR CODE                             #
    ##############################################################################

    return r2_oos, r2_is, b, v


def GBRT(lamv, mtype, ne, xtrain, ytrain, mtrain, xoos, yoos, xtest, ytest):
    '''
    Gradient Boosted Regression Trees (GBRT)
    =========================================
    
    GBRT builds an ensemble of shallow trees sequentially, where each new tree
    attempts to correct the errors made by the previous trees. The final prediction
    is a weighted sum of all trees, with a learning rate controlling the contribution
    of each tree.
    
    Parameters:
    -----------
    lamv : list of float
        Learning rate exponents (actual learning_rate = 10^lamv)
        Example: lamv=[-1.0, -0.8, ..., 0] → learning_rate=[0.1, 0.158, ..., 1.0]
        Lower learning rates require more trees but often generalize better
    mtype : str
        Loss function type:
        - "ls" (least squares): Standard L2 loss, sensitive to outliers
        - "huber": Robust loss, combines L2 for small errors and L1 for large errors
    ne : int
        Maximum number of boosting iterations (trees)
    xtrain, ytrain, mtrain, xoos, yoos, xtest, ytest : same as Random_forest()
    
    Returns:
    --------
    r2_oos, r2_is, b, v : same as Random_forest()
    
    Hyperparameters Tuned:
    ----------------------
    lamv : learning rate (via grid search)
    Number of estimators : automatically selected from 1 to ne based on test R²
    max_depth : fixed at 2 (shallow trees to prevent overfitting)
    
    Key Difference from Random Forest:
    ----------------------------------
    - Sequential learning: each tree focuses on previous errors
    - Learning rate controls step size (shrinkage prevents overfitting)
    - staged_predict() allows evaluation at each boosting iteration
    '''
    
    # Initialize output variables
    r2_oos = 0
    r2_is = 0
    b = np.zeros(xtrain.shape[1])
    v = np.zeros(xtrain.shape[1])

    # Storage for R² values across hyperparameter combinations
    # Dimensions: [learning_rates x number_of_trees]
    r = {}
    for i in range(3):
        r[i] = np.zeros((len(lamv), ne))

    # Grid search over learning rates
    for n1 in range(len(lamv)):
        lr = 10 ** lamv[n1]  # Convert exponent to actual learning rate
        
        ##############################################################################
        ### TODO: implement the function                                           ###
        ############################################################################## 
        # HINTS for students:
        # 1. Create a GradientBoostingRegressor with:
        #    - max_depth=2 (use shallow trees)
        #    - n_estimators=ne
        #    - learning_rate=lr
        #    - loss="squared_error" if mtype=="ls", or loss="huber" with alpha=0.99
        # 2. Fit the model on (xtrain, ytrain)
        # 3. Use staged_predict() to get predictions at each boosting stage (1 to ne trees)
        # 4. For each stage, compute R² on test/oos/train sets
        # 5. Store in r[0], r[1], r[2] respectively
        # 6. After grid search, retrain with best (learning_rate, n_estimators)
        # 7. Extract feature_importances_ and compute VIP
        ##############################################################################
        



        # Evaluate at each boosting stage (staged_predict returns generator)


    # Select best hyperparameters based on test R²


    # Retrain model with optimal hyperparameters


    # Extract feature importances


    # Calculate variable importance
   

    ##############################################################################
    #                               END OF YOUR CODE                             #
    ##############################################################################

    return r2_oos, r2_is, b, v


def MC_tree(MC=[1], datanum=100, horizon=[1], model=[1]):
    """
    Monte Carlo Simulation for Tree Models
    =======================================
    
    This function orchestrates the entire simulation process:
    1. Loads simulated data (characteristics and returns)
    2. Splits data into training, test, and out-of-sample sets
    3. Trains three tree models: Random Forest, GBRT, GBRT+Huber
    4. Saves performance metrics and feature importances
    
    Parameters:
    -----------
    MC : list of int
        Monte Carlo simulation identifiers (e.g., [1, 2, ..., 100])
    datanum : int
        Data size indicator (100 → 50 chars, 200 → 100 chars)
    horizon : list of int
        Return horizons ([1]=monthly, [3]=quarterly, [6]=semi-annual, [12]=annual)
    model : list of int
        Model specifications (typically [1])
    
    Data Split:
    -----------
    - Training: First 1/3 of time periods
    - Test: Middle 1/3 (for hyperparameter tuning)
    - Out-of-sample: Last 1/3 (for final evaluation)
    
    Outputs: R² scores, feature importances, and VIP scores
    """
    
    start = timeit.default_timer()

    for hh in horizon:
        title = path + '/Simu_' + str(datanum) + '/Tree%d' % hh
        if datanum == 100:
            nump = 50
        if datanum == 200:
            nump = 100

        for M in MC:
            write_dir()
            for mo in model:
                N = 200  # Number of firms
                m = nump * 2
                T = 180  # Number of time periods

                per = np.tile(np.arange(N) + 1, T)
                time = np.repeat(np.arange(T) + 1, N)
                stdv = 0.05
                theta_w = 0.005

                # Load data
                c = pd.read_csv(dirstock + 'c%d.csv' % M, delimiter=',').values
                r1 = pd.read_csv(dirstock + 'r%d_%d_%d.csv' % (mo, M, hh),
                                 delimiter=',').iloc[:, 0].values

                # Split data: Training (first 1/3)
                daylen = np.repeat(N, T // 3)
                daylen_test = daylen
                ind = range(0, (N * T // 3))
                xtrain = c[ind, :]
                ytrain = r1[ind]
                trainper = per[ind]
                
                # Test (middle 1/3)
                ind = range((N * T // 3), (N * (T * 2 // 3 - hh + 1)))
                xtest = c[ind, :]
                ytest = r1[ind]
                testper = per[ind]

                # Check data integrity
                l1 = c.shape[0]
                l2 = len(r1)
                l3 = l2 - np.sum(np.isnan(r1))
                print(l1, l2, l3)

                # Out-of-sample (last 1/3)
                ind = range((N * T * 2 // 3), min(l1, l2, l3))
                xoos = c[ind, :]
                yoos = r1[ind]
                del c
                del r1

                # Compute means for R² calculation
                ytrain_demean = ytrain - np.mean(ytrain)
                ytest_demean = ytest - np.mean(ytest)
                mtrain = np.mean(ytrain)
                mtest = np.mean(ytest)

                # Storage for results
                R2_oos = np.zeros(3)
                R2_is = np.zeros(3)

                ### Model 1: Random Forest ###
                ne = 100
                r2_oos, r2_is, b, v = Random_forest(nump, ne, xtrain, ytrain, mtrain, xoos, yoos, xtest, ytest)
                R2_oos[0] = r2_oos
                R2_is[0] = r2_is
                df = pd.DataFrame(b)
                df.to_csv(title + '/B/b%d_%d_%d.csv' % (mo, M, 0), header=False, index=False)
                df = pd.DataFrame(v)
                df.to_csv(title + '/VIP/b%d_%d_%d.csv' % (mo, M, 0), header=False, index=False)
                print('###RF Good!###')

                ### Model 2: GBRT ###
                lamv = sq(-1.0, 0, 0.2)
                ne = 50
                mtype = 'ls'
                r2_oos, r2_is, b, v = GBRT(lamv, mtype, ne, xtrain, ytrain, mtrain, xoos, yoos, xtest, ytest)
                R2_oos[1] = r2_oos
                R2_is[1] = r2_is
                df = pd.DataFrame(b)
                df.to_csv(title + '/B/b%d_%d_%d.csv' % (mo, M, 1), header=False, index=False)
                df = pd.DataFrame(v)
                df.to_csv(title + '/VIP/b%d_%d_%d.csv' % (mo, M, 1), header=False, index=False)
                print('###GBRT Good!###')

                ### Model 3: GBRT+Huber ###
                lamv = sq(-1.0, 0, 0.2)
                ne = 50
                mtype = 'huber'
                r2_oos, r2_is, b, v = GBRT(lamv, mtype, ne, xtrain, ytrain, mtrain, xoos, yoos, xtest, ytest)
                R2_oos[2] = r2_oos
                R2_is[2] = r2_is
                df = pd.DataFrame(b)
                df.to_csv(title + '/B/b%d_%d_%d.csv' % (mo, M, 2), header=False, index=False)
                df = pd.DataFrame(v)
                df.to_csv(title + '/VIP/b%d_%d_%d.csv' % (mo, M, 2), header=False, index=False)
                print('###GBRT huber Good!###')

                # Save performance metrics
                print(R2_oos)
                df = pd.DataFrame(R2_oos)
                df.to_csv(title + '/roos_%d_%d.csv' % (mo, M), header=False, index=False)
                print(R2_is)
                df = pd.DataFrame(R2_is)
                df.to_csv(title + '/ris_%d_%d.csv' % (mo, M), header=False, index=False)

    stop = timeit.default_timer()
    print('Time: ', stop - start)
