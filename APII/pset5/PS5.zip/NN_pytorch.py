"""
Neural Network Models for Empirical Asset Pricing - PyTorch Implementation

This module implements and trains multiple feedforward neural network architectures
to predict asset returns based on firm characteristics.

Features:
- 5 different neural network architectures (NN1-NN5) with varying depths
- Ensemble training with hyperparameter grid search
- Batch normalization and ReLU activations
- Early stopping with patience
- Learning rate scheduling
- Comprehensive logging and progress tracking

Citation: Gu, S., Kelly, B., & Xiu, D. (2020). "Empirical Asset Pricing via Machine Learning."
Review of Financial Studies, 33(5), 2223-2273.

PyTorch Version - Updated 2024
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import random
import timeit
import time
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from torch.optim.lr_scheduler import LambdaLR


# ==================== Global Configuration ====================
# Set random seeds for reproducibility
MC = 1
base_seed = MC * 123
random.seed(base_seed)
np.random.seed(base_seed)
torch.manual_seed(base_seed)

# Data configuration
datanum = "100"  # Can be "100" or "200" for different feature counts
path = "./Simu"
dirstock = path + "/SimuData_" + datanum + "/"


def write_dir(hh=[1]):
    """
    Create directory structure for saving model outputs.
    
    Creates subdirectories for:
    - B/: Hyperparameter selections
    - VIP/: Trained model parameters
    - M/: Additional model metadata
    
    Parameters:
    -----------
    hh : list of int
        Return horizons for which to create directories
    """
    for h in hh:
        title = path + "/Simu_" + datanum + "/NN%d" % h
        if not os.path.exists(title) and MC == 1:
            os.makedirs(title)
        if not os.path.exists(title + "/B") and MC == 1:
            os.makedirs(title + "/B")
        if not os.path.exists(title + "/VIP") and MC == 1:
            os.makedirs(title + "/VIP")
        if not os.path.exists(title + "/M") and MC == 1:
            os.makedirs(title + "/M")


# ==================== Neural Network Architectures ====================

class NNBase(nn.Module):
    """
    Base neural network class with customizable hidden layer architecture.
    
    Architecture:
    - Input layer: Takes firm characteristics
    - Hidden layers: Each with Linear -> BatchNorm -> ReLU
    - Output layer: Single neuron for return prediction
    
    All models use:
    - Kaiming (He) initialization for ReLU networks
    - Batch normalization for training stability
    - ReLU activations for non-linearity
    """
    
    def __init__(self, input_dim, layers, st):
        """
        Initialize the neural network.
        
        Parameters:
        -----------
        input_dim : int
            Number of input features (firm characteristics)
        layers : list of int
            Hidden layer dimensions, e.g., [32, 16, 8]
        st : float
            Standard deviation for weight initialization (not used with Kaiming)
        """
        super(NNBase, self).__init__()
        self.layers = nn.ModuleList()
        
        # Build hidden layers
        prev_dim = input_dim
        for dim in layers:
            # Standard feedforward block: Linear -> BatchNorm -> ReLU
            self.layers.append(nn.Linear(prev_dim, dim))
            self.layers.append(nn.BatchNorm1d(dim))
            self.layers.append(nn.ReLU())
            prev_dim = dim
        
        # Output layer: No activation (linear output for regression)
        self.layers.append(nn.Linear(prev_dim, 1))
        
        # Initialize weights using Kaiming initialization (optimal for ReLU)
        self._initialize_weights()
    
    def _initialize_weights(self):
        """
        Initialize network weights using Kaiming normal initialization.
        This is optimal for networks with ReLU activations.
        """
        for layer in self.layers:
            if isinstance(layer, nn.Linear):
                nn.init.kaiming_normal_(layer.weight, nonlinearity='relu')
                nn.init.zeros_(layer.bias)
    
    def forward(self, x):
        """
        Forward pass through the network.
        
        Parameters:
        -----------
        x : torch.Tensor
            Input features (batch_size, input_dim)
        
        Returns:
        --------
        torch.Tensor
            Predictions (batch_size, 1)
        """
        for layer in self.layers:
            x = layer(x)
        return x


# ==================== Specific Network Architectures ====================
# Five different architectures with increasing depth/complexity

class NN1(NNBase):
    """Single hidden layer: Input -> 32 -> Output"""
    def __init__(self, input_dim, st):
        super(NN1, self).__init__(input_dim, [32], st)


class NN2(NNBase):
    """Two hidden layers: Input -> 32 -> 16 -> Output"""
    def __init__(self, input_dim, st):
        super(NN2, self).__init__(input_dim, [32, 16], st)


class NN3(NNBase):
    """Three hidden layers: Input -> 32 -> 16 -> 8 -> Output"""
    def __init__(self, input_dim, st):
        super(NN3, self).__init__(input_dim, [32, 16, 8], st)


class NN4(NNBase):
    """Four hidden layers: Input -> 32 -> 16 -> 8 -> 4 -> Output"""
    def __init__(self, input_dim, st):
        super(NN4, self).__init__(input_dim, [32, 16, 8, 4], st)


class NN5(NNBase):
    """Five hidden layers: Input -> 32 -> 16 -> 8 -> 4 -> 2 -> Output"""
    def __init__(self, input_dim, st):
        super(NN5, self).__init__(input_dim, [32, 16, 8, 4, 2], st)


# ==================== Training and Evaluation ====================

def train_and_test_model(redo, lrv, lamv, st, ep, bs, hh, npatience, 
                        xtrain, ytrain, mtrain, xoos, yoos, moos, 
                        xtest, ytest, model_class):
    """
    Train neural network with hyperparameter grid search and ensemble averaging.
    
    Training Strategy:
    1. Grid search over learning rates and weight decay values
    2. For each configuration, train with early stopping
    3. Select best model based on validation loss
    4. Repeat for multiple ensemble members (redo times)
    5. Average predictions across ensemble for final forecasts
    
    Parameters:
    -----------
    redo : int
        Number of ensemble models to train
    lrv : list of float
        Learning rates to try
    lamv : list of float
        Weight decay exponents (actual decay = 10^lamv)
    st : float
        Standard deviation for initialization
    ep : int
        Maximum epochs per training run
    bs : int
        Batch size
    hh : int
        Return horizon
    npatience : int
        Early stopping patience (epochs)
    xtrain, ytrain : array
        Training features and targets
    mtrain : float
        Mean of training targets (for R² baseline)
    xoos, yoos : array
        Out-of-sample features and targets
    moos : float
        Mean of out-of-sample targets
    xtest, ytest : array
        Validation features and targets
    model_class : class
        Neural network class to instantiate (NN1-NN5)
    
    Returns:
    --------
    se0 : ndarray
        Best hyperparameters for each ensemble (redo × 3)
        Columns: [lr_index, weight_decay_index, best_epoch]
    r2_is : float
        In-sample R² (on training set)
    r2_oos : float
        Out-of-sample R² (on test set)
    b : list
        List of trained models (ensemble)
    """
    
    # Initialize storage
    mlist = {}  # Dictionary to store trained models
    se0 = np.zeros((redo, 3))  # Store best hyperparameters
    b = []  # List of best models
    
    # Setup device (GPU if available, otherwise CPU)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Convert data to PyTorch tensors and move to device
    xtrain = torch.Tensor(xtrain).to(device)
    ytrain = torch.Tensor(ytrain).to(device)
    xtest = torch.Tensor(xtest).to(device)
    ytest = torch.Tensor(ytest).to(device)
    xoos = torch.Tensor(xoos).to(device)
    yoos = torch.Tensor(yoos).to(device)
    
    # Print training configuration
    print(f"\n{'='*70}")
    print(f"Training {model_class.__name__} with {redo} ensemble models")
    print(f"Device: {device}")
    print(f"Hyperparameter grid: {len(lrv)} learning rates × {len(lamv)} weight decays = {len(lrv) * len(lamv)} configs")
    print(f"{'='*70}")
    
    overall_start = time.time()
    
    # ==================== Ensemble Training Loop ====================
    for count in range(redo):
        ensemble_start = time.time()
        print(f"\n[Ensemble {count+1}/{redo}] Starting hyperparameter search...")
        
        # Reset random seed for each ensemble member
        seed = base_seed * (count + 1)
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        
        # Track best model for this ensemble
        best_train_losses = []
        best_val_losses = []
        minloss = float('inf')
        total_configs = len(lrv) * len(lamv)
        config_count = 0
        
        # ==================== Hyperparameter Grid Search ====================
        for n1 in range(len(lrv)):
            lr = lrv[n1]
            
            for n2 in range(len(lamv)):
                config_count += 1
                weight_decay = 10 ** lamv[n2]
                
                # Print progress (selectively to avoid clutter)
                should_print = (config_count == 1 or 
                               config_count == total_configs or 
                               (total_configs > 10 and config_count % 3 == 0) or
                               (total_configs <= 10))
                
                if should_print:
                    print(f"  [{config_count:2d}/{total_configs}] lr={lr:.4f}, wd={weight_decay:.6f}", 
                          end='', flush=True)
                
                # ==================== Initialize Model and Optimizer ====================
                model = model_class(xtrain.shape[1], st).to(device)
                optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
                
                # Learning rate scheduler: lr_t = lr_0 / (1 + λ*t)
                scheduler = LambdaLR(optimizer, lr_lambda=lambda epoch: 1 / (1 + 1e-4 * epoch))
                
                # Mean squared error loss for regression
                criterion = nn.MSELoss()
                
                # Create data loaders for mini-batch training
                train_loader = DataLoader(
                    TensorDataset(xtrain, ytrain / hh),  # Normalize targets by horizon
                    batch_size=bs, 
                    shuffle=True
                )
                val_loader = DataLoader(
                    TensorDataset(xtest, ytest / hh), 
                    batch_size=bs, 
                    shuffle=False
                )
                
                # Early stopping setup
                best_val_loss = float('inf')
                patience = npatience
                best_model_wts = None
                
                # Track losses for plotting
                train_losses = []
                val_losses = []
                
                # ==================== Training Loop ====================
                for epoch in range(ep):
                    # --- Training Phase ---
                    model.train()
                    train_loss = 0.0
                    
                    for inputs, targets in train_loader:
                        optimizer.zero_grad()
                        outputs = model(inputs)
                        loss = criterion(outputs.squeeze(), targets)
                        loss.backward()
                        optimizer.step()
                        train_loss += loss.item() * inputs.size(0)
                    
                    train_loss /= len(train_loader.dataset)
                    train_losses.append(train_loss)
                    
                    # --- Validation Phase ---
                    model.eval()
                    val_loss = 0.0
                    
                    with torch.no_grad():
                        for inputs, targets in val_loader:
                            outputs = model(inputs)
                            loss = criterion(outputs.squeeze(), targets)
                            val_loss += loss.item() * inputs.size(0)
                    
                    val_loss /= len(val_loader.dataset)
                    val_losses.append(val_loss)
                    
                    # Update learning rate
                    scheduler.step()
                    
                    # --- Early Stopping Check ---
                    if val_loss < best_val_loss:
                        best_val_loss = val_loss
                        patience = npatience  # Reset patience
                        best_model_wts = model.state_dict().copy()
                    else:
                        patience -= 1
                        if patience == 0:
                            break  # Early stop triggered
                
                # Load best weights from this training run
                model.load_state_dict(best_model_wts)
                
                # Print result for this configuration
                if should_print:
                    print(f" → val_loss={best_val_loss:.6f} (stopped at epoch {epoch+1})")
                
                # --- Update Best Model for Ensemble ---
                if best_val_loss < minloss:
                    minloss = best_val_loss
                    se0[count, :] = np.array([n1, n2, epoch])
                    best_model = model
                    best_train_losses = train_losses.copy()
                    best_val_losses = val_losses.copy()
        
        # ==================== Ensemble Summary ====================
        ensemble_time = time.time() - ensemble_start
        print(f"\n[Ensemble {count+1}/{redo}] Completed in {ensemble_time:.1f}s")
        print(f"  Best config: lr_idx={int(se0[count, 0])}, wd_idx={int(se0[count, 1])}, stopped_epoch={int(se0[count, 2])+1}")
        print(f"  Best val_loss: {minloss:.6f}")
        
        # Estimate remaining time
        if count < redo - 1:
            avg_time_per_ensemble = (time.time() - overall_start) / (count + 1)
            remaining_time = avg_time_per_ensemble * (redo - count - 1)
            print(f"  Estimated time remaining for this model: {remaining_time/60:.1f} min")
        
        # Store best model
        b.append(best_model)
        mlist[count] = best_model
        
        # ==================== Visualize First Ensemble ====================
        # Only plot for first ensemble to avoid clutter
        if count == 0:
            plt.figure(figsize=(10, 6))
            plt.plot(best_train_losses, label='Train Loss', linewidth=2)
            plt.plot(best_val_losses, label='Validation Loss', linewidth=2)
            plt.title(f'{model_class.__name__} - Ensemble 1 - Model Loss')
            plt.xlabel('Epoch')
            plt.ylabel('Loss')
            plt.legend()
            plt.grid(True, alpha=0.3)
            plt.show()
            print(f"  Min train loss: {np.min(best_train_losses):.6f}")
            print(f"  Min val loss: {np.min(best_val_losses):.6f}")
    
    # ==================== Ensemble Predictions ====================
    print(f"\n{'='*70}")
    print(f"Computing ensemble predictions...")
    
    # In-sample predictions (training set)
    yhat1 = 0
    for i in range(redo):
        best_model = mlist[i]
        best_model.eval()
        with torch.no_grad():
            yhat1 += best_model(xtrain).cpu().numpy()[:, 0]
    yhat1 = yhat1 / redo * hh  # Average and rescale
    
    # Out-of-sample predictions (test set)
    yhat2 = 0
    for i in range(redo):
        best_model = mlist[i]
        best_model.eval()
        with torch.no_grad():
            yhat2 += best_model(xoos).cpu().numpy()[:, 0]
    yhat2 = yhat2 / redo * hh  # Average and rescale
    
    # ==================== Calculate R² ====================
    # R² = 1 - SS_res / SS_tot
    # where SS_res = Σ(y - ŷ)² and SS_tot = Σ(y - ȳ)²
    
    ytrain_np = ytrain.cpu().numpy()
    yoos_np = yoos.cpu().numpy()
    
    r2_is = 1 - np.mean((ytrain_np - yhat1)**2) / np.mean((ytrain_np - mtrain)**2)
    r2_oos = 1 - np.mean((yoos_np - yhat2)**2) / np.mean((yoos_np - moos)**2)
    
    total_time = time.time() - overall_start
    print(f"Total training time for {model_class.__name__}: {total_time/60:.2f} min")
    print(f"{'='*70}\n")
    
    return se0, r2_is, r2_oos, b


# ==================== Main Execution Function ====================

def MC_NN_pytorch(MC=[1], datanum=100, horizon=[1], model=[1], redo=5):
    """
    Run Monte Carlo simulations for neural network asset pricing models.
    
    This function:
    1. Loads simulated data from DGP
    2. Splits into train/validation/test sets
    3. Normalizes features
    4. Trains 5 different NN architectures with ensemble learning
    5. Evaluates in-sample and out-of-sample performance
    6. Saves results and trained models
    
    Parameters:
    -----------
    MC : list of int
        Monte Carlo iteration numbers to run
    datanum : int
        Number of characteristics (50 or 100)
    horizon : list of int
        Return horizons (e.g., [1] for 1-month)
    model : list of int
        Model specifications to use (1=linear, 2=nonlinear from DGP)
    redo : int
        Number of ensemble models per architecture
    
    Data Split:
    -----------
    - Training: First 1/3 of time periods
    - Validation: Middle 1/3 of time periods
    - Out-of-sample test: Last 1/3 of time periods
    """
    
    start = timeit.default_timer()
    models = [NN1, NN2, NN3, NN4, NN5]
    
    # Print experiment configuration
    print("\n" + "="*70)
    print("STARTING NEURAL NETWORK TRAINING")
    print("="*70)
    print(f"Monte Carlo runs: {MC}")
    print(f"Data size: {datanum}")
    print(f"Horizons: {horizon}")
    print(f"Models to train: {model}")
    print(f"Ensemble size (redo): {redo}")
    print(f"Number of NN architectures: {len(models)}")
    print("="*70 + "\n")
    
    # ==================== Loop Over Horizons ====================
    for hh in horizon:
        print(f"\n{'#'*70}")
        print(f"HORIZON {hh}")
        print(f"{'#'*70}")
        
        title = f"./Simu/Simu_{datanum}/NN{hh}"
        
        # Set number of characteristics based on data size
        if datanum == 100:
            nump = 50
        elif datanum == 200:
            nump = 100
        
        npatience = 3  # Early stopping patience
        
        # ==================== Loop Over Monte Carlo Runs ====================
        for M in MC:
            print(f"\n--- Monte Carlo Run: {M} ---")
            write_dir()
            
            # ==================== Loop Over Model Specifications ====================
            for mo in model:
                print(f"\n--- Model Configuration: {mo} ---")
                
                # Data dimensions
                N = 200  # Number of firms
                T = 180  # Number of time periods
                
                # ==================== Load Data ====================
                print("Loading data...")
                c = pd.read_csv(f"./Simu/SimuData_{datanum}/c{M}.csv", delimiter=",").values
                r1 = pd.read_csv(f"./Simu/SimuData_{datanum}/r{mo}_{M}_{hh}.csv", 
                                delimiter=",").iloc[:, 0].values
                
                # ==================== Split Data ====================
                # Training set: First 1/3 of time series
                ind = range(0, N * T // 3)
                xtrain, ytrain = c[ind, :], r1[ind]
                
                # Validation set: Middle 1/3 of time series
                ind = range(N * T // 3, N * (T * 2 // 3 - hh + 1))
                xtest, ytest = c[ind, :], r1[ind]
                
                # Out-of-sample test: Last 1/3 of time series
                ind = range(N * T * 2 // 3, 
                           min(c.shape[0], len(r1), len(r1) - np.sum(np.isnan(r1))))
                xoos, yoos = c[ind, :], r1[ind]
                
                # Calculate means for R² computation
                mtrain = np.mean(ytrain)
                mtest = np.mean(ytest)
                moos = np.mean(yoos)
                
                # ==================== Normalize Features ====================
                # Standardize each feature using training set statistics
                print("Normalizing features...")
                sd = np.zeros(xtrain.shape[1])
                
                for i in range(xtrain.shape[1]):
                    s = np.std(xtrain[:, i])
                    if s > 0:
                        # Standardize: (x - 0) / std (already centered from DGP)
                        xtrain[:, i] = xtrain[:, i] / s
                        xtest[:, i] = xtest[:, i] / s
                        xoos[:, i] = xoos[:, i] / s
                        sd[i] = s
                
                print(f"Data shapes: train={xtrain.shape}, test={xtest.shape}, oos={xoos.shape}")
                
                # ==================== Hyperparameter Grid ====================
                # Weight decay: 10^lamv for lamv in [-4.0, -1.0]
                lamv = np.arange(-4.0, -1.0, 0.2)
                # Learning rates
                lrv = [1e-3, 1e-2]
                
                # Training configuration
                ep = 100   # Maximum epochs
                bs = 256   # Batch size
                st = 0.05  # Initialization standard deviation (not used with Kaiming)
                
                # ==================== Train All Architectures ====================
                r2_is_list = []
                r2_oos_list = []
                model_start_time = time.time()
                
                for model_idx, model_class in enumerate(models):
                    print(f"\n*** Training Architecture {model_idx+1}/{len(models)}: {model_class.__name__} ***")
                    
                    # Train model with ensemble
                    se0, r2_is, r2_oos, b = train_and_test_model(
                        redo, lrv, lamv, st, ep, bs, hh, npatience, 
                        xtrain, ytrain, mtrain, xoos, yoos, moos, xtest, ytest, 
                        model_class
                    )
                    
                    # Print results
                    model_name = model_class.__name__
                    print(f"\n*** Results for {model_name}: ***")
                    print(f"  R² (in-sample):     {r2_is:.6f}")
                    print(f"  R² (out-of-sample): {r2_oos:.6f}")
                    print(f"  Best hyperparameters per ensemble:")
                    for i in range(len(se0)):
                        print(f"    Ensemble {i+1}: lr_idx={int(se0[i, 0])}, " +
                              f"wd_idx={int(se0[i, 1])}, epoch={int(se0[i, 2])+1}")
                    
                    # Save results
                    pd.DataFrame(b).to_csv(
                        f"{title}/VIP/b{mo}_{M}_{model_name}.csv", 
                        header=False, index=False
                    )
                    pd.DataFrame(se0).to_csv(
                        f"{title}/B/se{mo}_{M}_{model_name}.csv", 
                        header=False, index=False
                    )
                    
                    r2_is_list.append(r2_is)
                    r2_oos_list.append(r2_oos)
                    
                    # Estimate remaining time
                    elapsed = time.time() - model_start_time
                    avg_time_per_model = elapsed / (model_idx + 1)
                    remaining = avg_time_per_model * (len(models) - model_idx - 1)
                    print(f"\n  Progress: {model_idx+1}/{len(models)} models completed")
                    print(f"  Estimated time remaining: {remaining/60:.1f} min")
                
                # ==================== Save Summary Results ====================
                pd.DataFrame(r2_is_list).to_csv(
                    f"{title}/r2_is_{mo}_{M}.csv", 
                    header=False, index=False
                )
                pd.DataFrame(r2_oos_list).to_csv(
                    f"{title}/r2_oos_{mo}_{M}.csv", 
                    header=False, index=False
                )
                
                # Print final summary
                print(f"\n{'='*70}")
                print(f"SUMMARY - All models for configuration (mo={mo}, M={M}, hh={hh})")
                print(f"{'='*70}")
                for i, model_class in enumerate(models):
                    print(f"{model_class.__name__:5s}: R²_is={r2_is_list[i]:7.4f}, " +
                          f"R²_oos={r2_oos_list[i]:7.4f}")
                print(f"{'='*70}\n")
    
    # ==================== Overall Summary ====================
    stop = timeit.default_timer()
    total_time = stop - start
    print(f"\n{'#'*70}")
    print(f"TOTAL EXECUTION TIME: {total_time/60:.2f} minutes ({total_time/3600:.2f} hours)")
    print(f"{'#'*70}\n")


# ==================== Script Entry Point ====================
if __name__ == "__main__":
    """
    Example usage: Train all 5 architectures on simulated data
    """
    MC_NN_pytorch(MC=[1], datanum=100, horizon=[1], model=[1], redo=5)
